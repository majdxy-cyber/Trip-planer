// אינטראקציה בסיסית לטופס תכנון
const form = document.getElementById('tripForm');
const resultEl = document.getElementById('result');
const startBtn = document.getElementById('startBtn');

if (startBtn) {
  startBtn.addEventListener('click', () => {
    document.querySelector('#plan')?.scrollIntoView({ behavior: 'smooth' });
  });
}

form?.addEventListener('submit', (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());

  // הערכת זמן בסיסית לפי מצב (פיקטיבי לצורך הדגמה)
  const mode = (data.mode || '').toString();
  let speed = 40; // קמ"ש ברירת מחדל
  if (mode.includes('קטנוע')) speed = 35;
  if (mode.includes('רכבת')) speed = 80;
  if (mode.includes('אוטובוס')) speed = 55;
  if (mode.includes('רכב')) speed = 70;

  // נציג "מסלול מוצע" טקסטואלי
  const html = `
    <div class="result-card">
      <strong>מסלול נבנה:</strong><br/>
      <span>מ־<b>${data.from || 'מוצא'}</b> אל <b>${data.to || 'יעד'}</b></span><br/>
      <span>🗓️ ${data.dateStart || '—'} עד ${data.dateEnd || '—'}</span><br/>
      <span>🚍 מצב: ${mode || '—'}, מהירות ממוצעת ~${speed} קמ״ש</span><br/>
      <span>💸 תקציב יומי: ${data.budget ? '₪' + data.budget : '—'}</span>
    </div>
  `;
  resultEl.innerHTML = html;
});
