# טיול-תפור – V2 (פשטני)
כולל clean URLs, 404, שיתוף וואטסאפ, קישור שיתוף, וסטייל משודרג.
קבצים: index.html, planner.html, styles.css, script.js, 404.html, vercel.json.
