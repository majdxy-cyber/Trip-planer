const DATA={Bangkok:{base:[
{name:"ארמון המלך והמרכז ההיסטורי",type:["culture","family","couple","honeymoon","friends"],area:"מרכז",time:"בוקר"},
{name:"ואט פו – בודהה השוכב",type:["culture","family","couple","honeymoon"],area:"מרכז",time:"צהריים"},
{name:"שוק סוף השבוע צ'טוצ'אק",type:["family","friends","couple"],area:"צפון",time:"בוקר"},
{name:"צ'יינה טאון + אוכל רחוב",type:["family","friends","couple"],area:"מרכז",time:"ערב"},
{name:"ICONSIAM + מופע מזרקות",type:["family","couple","honeymoon"],area:"נהר",time:"ערב"},
{name:"שווקים צפים + רכבת מאקלונג",type:["family","couple","honeymoon"],area:"מחוץ לעיר",time:"חצי יום"},
{name:"רוף-טופ שקיעה",type:["couple","honeymoon","friends"],area:"מרכז",time:"ערב"},
{name:"חיי לילה קאו-סאן/סוי 11",type:["friends"],area:"מרכז",time:"לילה"}],
family:[{name:"Sea Life אקוואריום",time:"בוקר"},{name:"KidZania/פארק חבלים",time:"צהריים"}],
couple:[{name:"סיור סירה על הנהר",time:"צהריים"}],
honeymoon:[{name:"Dinner Cruise",time:"ערב"},{name:"מסאז' זוגי ספא",time:"צהריים"}],
friends:[{name:"מועדונים RCA/Thonglor",time:"לילה"}]},
Phuket:{base:[
{name:"חופי פאטונג/קארון/קטה – בוקר ים",type:["family","couple","honeymoon","friends"],area:"חוף",time:"בוקר"},
{name:"תצפית קארון/פרומטפ – שקיעה",type:["family","couple","honeymoon","friends"],area:"דרום",time:"ערב"},
{name:"עיר עתיקה פוקט – קפה וצילום",type:["family","couple","honeymoon"],area:"עיר עתיקה",time:"צהריים"},
{name:"איי פי-פי/מאיה ביי – שיט",type:["family","couple","honeymoon","friends"],area:"שיט",time:"יום מלא"},
{name:"Big Buddha + ואט צ'לונג",type:["family","couple","honeymoon"],area:"מרכז",time:"בוקר"},
{name:"Bangla Road – חיי לילה",type:["friends"],area:"פאטונג",time:"לילה"}],
family:[{name:"פארק מים Andamanda",time:"יום חלקי"}],
couple:[{name:"וילה עם בריכה/חוף חבוי",time:"בוקר"}],
honeymoon:[{name:"שקיעה נאי-הרן + מסעדה",time:"ערב"}],
friends:[{name:"ספורט ימי/ג'ט סקי",time:"צהריים"}]},
ChiangMai:{base:[
{name:"עיר עתיקה – מקדשים ואווירה",type:["family","couple","honeymoon","friends"],area:"מרכז",time:"בוקר"},
{name:"דוי סוטפ – תצפית",type:["family","couple","honeymoon","friends"],area:"הר",time:"צהריים"},
{name:"Night Bazaar / Sunday Walking",type:["family","couple","friends"],area:"מרכז",time:"ערב"},
{name:"קורס בישול תאילנדי",type:["family","couple","honeymoon"],area:"חווה",time:"חצי יום"}],
family:[{name:"פארק פילים אתי (ללא רכיבה)",time:"יום מלא"}],
couple:[{name:"קפה/מפלים Mae Sa",time:"צהריים"}],
honeymoon:[{name:"ספא זוגי + קפה נוף",time:"צהריים"}],
friends:[{name:"קניונינג/זיפליין",time:"חצי יום"}]}};
const BUDGETS={low:{label:"חסכוני",range:"₪200–350 לאדם ליום"},mid:{label:"ביניים",range:"₪350–700 לאדם ליום"},high:{label:"יוקרתי",range:"₪700+ לאדם ליום"}};
const TYPE_LABELS={family:"משפחתי",couple:"זוגי",honeymoon:"ירח דבש",friends:"רווקים/רווקות"};
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>r.querySelectorAll(s);
function initChoices(){$$(".choices").forEach(g=>{g.addEventListener("click",e=>{const b=e.target.closest(".choice");if(!b)return;g.querySelectorAll(".choice").forEach(x=>x.classList.remove("is-selected"));b.classList.add("is-selected");if(b.dataset.budget)$("#budget").value=b.dataset.budget;if(b.dataset.type)$("#tripType").value=b.dataset.type;});});}
function pickItems(base,extra,days){const plan=[];let i=0;for(let d=1;d<=days;d++){const slots=[];for(let s=0;s<3;s++){const it=base[(i+s)%base.length];if(it)slots.push(it);}if(extra.length&&d%2===0){const add=extra[(d/2-1)%extra.length];slots.push(add);}i+=2;plan.push(slots);}return plan;}
function labelDest(d){return{Bangkok:"בנגקוק",Phuket:"פוקט",ChiangMai:"צ'יאנג מאי"}[d]||d;}
function escapeHTML(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML;}
function buildItinerary({destination,days,budget,tripType,notes}){const baseAll=DATA[destination].base.filter(p=>p.type?.includes(tripType)||p.type?.includes("family")||p.type?.length===undefined);const extra=DATA[destination][tripType]||[];const plan=pickItems(baseAll,extra,days);$("#summary").innerHTML=`<div class="kpi"><strong>יעד:</strong><br>${labelDest(destination)}</div><div class="kpi"><strong>משך:</strong><br>${days} ימים</div><div class="kpi"><strong>סוג טיול:</strong><br>${TYPE_LABELS[tripType]}</div><div class="kpi"><strong>תקציב:</strong><br>${BUDGETS[budget].label} – ${BUDGETS[budget].range}</div>${notes?`<div class="kpi"><strong>העדפות:</strong><br>${escapeHTML(notes)}</div>`:""}`;const wrap=$("#itinerary");wrap.innerHTML="";plan.forEach((slots,idx)=>{const day=document.createElement("div");day.className="day";day.innerHTML=`<h3>יום ${idx+1}</h3>`;slots.forEach(p=>{const tag=(p.time?`<span class="badge">${p.time}</span>`:"");day.innerHTML+=`<div class="place">${p.name} ${tag} ${p.area?`<small>אזור: ${p.area}</small>`:""}</div>`;});wrap.appendChild(day);});const text=`מסלול לתאילנד – ${labelDest(destination)} (${days} ימים)
סוג טיול: ${TYPE_LABELS[tripType]}
תקציב: ${BUDGETS[budget].label} – ${BUDGETS[budget].range}
${notes? "העדפות: "+notes+"\n": ""}`;$("#shareWA").href="https://wa.me/?text="+encodeURIComponent(text);}
function applyParams(){const p=new URLSearchParams(location.search);if(p.has("destination"))$("#destination").value=p.get("destination");if(p.has("days"))$("#days").value=p.get("days");if(p.has("budget")){$("#budget").value=p.get("budget");$$('[data-budget]').forEach(b=>b.classList.toggle('is-selected',b.dataset.budget===p.get("budget")));}if(p.has("tripType")){$("#tripType").value=p.get("tripType");$$('[data-type]').forEach(b=>b.classList.toggle('is-selected',b.dataset.type===p.get("tripType")));}}
function buildShareLink({destination,days,budget,tripType}){const u=new URL(location.href);u.search=new URLSearchParams({destination,days,budget,tripType}).toString();const a=$("#shareLink"),w=$("#shareLinkWrap");if(a&&w){a.href=u.toString();w.hidden=false;}}
function setupForm(){const form=$("#plannerForm");const results=$("#results");$("#year")?.textContent=new Date().getFullYear();$("#printBtn")?.addEventListener("click",()=>window.print());form.addEventListener("submit",e=>{e.preventDefault();const destination=$("#destination").value;const days=Math.max(2,Math.min(30,parseInt($("#days").value||"7",10)));const budget=$("#budget").value;const tripType=$("#tripType").value;const notes=$("#notes").value.trim();buildItinerary({destination,days,budget,tripType,notes});buildShareLink({destination,days,budget,tripType});results.hidden=false;results.scrollIntoView({behavior:"smooth",block:"start"});});}
document.addEventListener("DOMContentLoaded",()=>{initChoices();setupForm();applyParams();});